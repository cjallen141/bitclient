Readme.txt

You want to make sure you have all the libraries

Bencode
Bitstring
Requests

In order to run, you need to do this

python TorrentManager.py -f <torrent file> 

There are some other command line options that you can
figure out by running

python TorrentManager.py --Help